let handler = async (m, { command, text }) => {
  m.reply(`
*Question:* ${command} ${text}
*Answer:* ${pickRandom(['Ya', 'Maybe yes', 'Possible', 'Probably not', 'Not', 'Impossible'])}
`.trim())
}
handler.help = ['apakah <pertanyaan>']
handler.tags = ['kerang']
handler.command = /^apakah$/i

module.exports = handler

function pickRandom(list) {
  return list[Math.floor(Math.random() * list.length)]
}